import {MODULE_ID,LABELS,makeActor,validateCatalogue} from './core.mjs';
let catalogue=[];
let busy=false;
const escapeHTML = v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const alertGM = ()=>{if(!game.user?.isGM){ui.notifications.warn('Эти инструменты доступны только ведущему.');return false;}return true;};
async function importBiome(biome='all') {
  if(!alertGM() || busy)return;
  busy=true;
  try{
    if(!catalogue.length)await loadCatalogue();
    const sample=biome==='all'?catalogue:catalogue.filter(r=>r.biome===biome);
    const owned=new Set(game.actors.contents.map(a=>a.getFlag?.(MODULE_ID,'id') || a.flags?.[MODULE_ID]?.id).filter(Boolean));
    let imported=0,skipped=0;
    const groups=[...new Set(sample.map(x=>x.biome))];
    for(const group of groups){
      const title=`Moonlighter — ${LABELS[group]||group}`;
      let folder=game.folders.contents.find(f=>f.name===title && f.type==='Actor');
      if(!folder)folder=await Folder.create({name:title,type:'Actor',color:'#468e8a'});
      const records=sample.filter(r=>r.biome===group);
      const next=records.filter(r=>!owned.has(r.id));
      skipped+=records.length-next.length;
      if(!next.length)continue;
      const data=next.map(r=>({...makeActor(r),folder:folder.id}));
      await Actor.createDocuments(data);
      imported+=data.length;
    }
    ui.notifications.info(`Moonlighter Bestiary: добавлено ${imported} существ, уже существовали ${skipped}.`);
  }catch(e){console.error('Moonlighter Bestiary import failed',e);ui.notifications.error(`Ошибка импорта: ${e.message}`);}finally{busy=false;}
}
async function loadCatalogue() {
  const resp=await fetch(`modules/${MODULE_ID}/data/monsters.json`);
  if(!resp.ok)throw new Error(`Ошибка чтения каталога: HTTP ${resp.status}`);
  catalogue=await resp.json();validateCatalogue(catalogue);
}
function formHTML() {
 const counts=Object.fromEntries(Object.keys(LABELS).map(k=>[k,catalogue.filter(r=>r.biome===k).length]));
 return `<div class="mlb">
  <p>94 существа Moonlighter: обычные противники, боссы и фамильяры. Каждый NPC содержит портрет, токен, атаки и способности D&D 5e.</p>
  <div class="mlb-groups">${Object.entries(LABELS).map(([k,label])=>`<button type="button" data-import="${k}"><strong>${escapeHTML(label)}</strong><small>${counts[k]} существ</small></button>`).join('')}</div>
  <p class="mlb-note">Повторный импорт пропускает уже созданных существ. Кнопка «Все» импортирует каталог в отдельные папки актёров. Для генератора выбери нужную папку противников.</p>
  </div>`;
}
async function openCatalogue(){
 if(!alertGM())return;
 if(!catalogue.length)await loadCatalogue();
 const dlg=new foundry.applications.api.DialogV2({window:{title:'Moonlighter Bestiary — каталог',resizable:true},
  content:formHTML(),buttons:[{action:'import',label:'Импортировать все 94',icon:'fa-solid fa-boxes-stacked',callback:()=>importBiome('all')},
    {action:'close',label:'Закрыть'}]});
 await dlg.render({force:true});
 for(const btn of dlg.element.querySelectorAll('[data-import]')){
   btn.addEventListener('click',async()=>{btn.disabled=true;try{await importBiome(btn.dataset.import)}finally{btn.disabled=false}});
 }
}
function getSelectedActor(){
 const controlled=canvas.tokens?.controlled||[];
 if(controlled.length!==1)throw Error('Выдели ровно один токен существа Moonlighter на сцене.');
 const token=controlled[0],actions=token.actor?.getFlag?.(MODULE_ID,'actions')||token.actor?.flags?.[MODULE_ID]?.actions;
 if(!actions)throw Error('Выделенный токен не относится к Moonlighter Bestiary.');
 return {token,actions};
}
function targets(){return [...(game.user.targets||[])].filter(t=>t.actor)};
async function sendRoll(formula,flavor,token){
 const roll=await new Roll(formula).evaluate();
 await roll.toMessage({speaker:ChatMessage.getSpeaker({token}),flavor});
 return roll.total;
}
const abilityMod=(actor,ability)=>{
 const a=actor?.system?.abilities?.[ability];
 const value=Number(a?.value||10);const base=Number(a?.mod??Math.floor((value-10)/2));
 const prof=a?.proficient?Number(actor.system?.attributes?.prof||2):0;
 return base+prof;
};
async function applyDamage(actor,value){
 const max=Number(actor.system?.attributes?.hp?.max||999);
 const hp=Number(actor.system?.attributes?.hp?.value||0);
 await actor.update({'system.attributes.hp.value':Math.max(0,Math.min(max,hp-value))});
}
async function applyCondition(actor,condition,origin){
 if(!['poisoned','prone','restrained','frightened','grappled'].includes(condition))return;
 // Status effects are recognizable by core/dnd5e. Duration handling relies on the combat tracker.
 await actor.createEmbeddedDocuments('ActiveEffect',[{name:`Moonlighter: ${condition}`,statuses:[condition],origin,
   duration:{rounds:1},flags:{[MODULE_ID]:{temporary:true}}}]);
}
async function performAction(abilityKey,autoApply){
 if(!alertGM())return;
 const {token,actions}=getSelectedActor();
 const action=actions.find(a=>a.key===abilityKey);
 if(!action)throw new Error('Способность не найдена.');
 const selected=targets();
 if(!selected.length){
   if(action.mode==='attack'){
     await sendRoll(`1d20+${action.bonus}`,`${token.name}: ${action.name} (атака)`,token);
     await sendRoll(action.damage,`${token.name}: ${action.name} — урон (${action.damageType})`,token);
   }else{
     await ChatMessage.create({speaker:ChatMessage.getSpeaker({token}),content:`<p><strong>${escapeHTML(action.name)}</strong>: спасбросок ${escapeHTML(action.save.toUpperCase())} Сл ${action.dc}. ${escapeHTML(action.description)}</p>`});
     await sendRoll(action.damage,`${token.name}: ${action.name} — урон`,token);
   }
   return;
 }
 if(action.mode==='attack'){
   for(const target of selected){
     const roll=await sendRoll(`1d20+${action.bonus}`,`${token.name}: ${action.name} против ${target.name}`,token);
     const ac=Number(target.actor.system?.attributes?.ac?.value||10);
     const hit=(roll-action.bonus===20)||(roll-action.bonus!==1 && roll>=ac);
     await ChatMessage.create({speaker:ChatMessage.getSpeaker({token}),content:`<p>${escapeHTML(target.name)}: ${hit?'Попадание':'Промах'} (КД ${ac}).</p>`});
     if(hit){const damage=await sendRoll(action.damage,`${action.name} — ${action.damageType}`,token);if(autoApply)await applyDamage(target.actor,damage);}
   }
 }else{
   const damage=await sendRoll(action.damage,`${token.name}: ${action.name} — урон при провале`,token);
   for(const target of selected){
     const mod=abilityMod(target.actor,action.save);
     const result=await sendRoll(`1d20+${mod}`,`${target.name}: спасбросок ${action.save.toUpperCase()} Сл ${action.dc}`,target);
     const success=result>=action.dc;
     const dealt=success?Math.floor(damage/2):damage;
     if(autoApply){await applyDamage(target.actor,dealt);if(!success && action.condition)await applyCondition(target.actor,action.condition,token.actor.uuid);}
     await ChatMessage.create({speaker:ChatMessage.getSpeaker({token}),content:`<p>${escapeHTML(target.name)}: ${success?'Успешно':'Провал'} (${result} против ${action.dc}). Урон ${dealt} (${escapeHTML(action.damageType)}). ${!success&&action.condition?`Состояние: ${escapeHTML(action.condition)}.`:''}</p>`});
   }
 }
}
async function openActions(){
 if(!alertGM())return;
 let selected;
 try{selected=getSelectedActor()}catch(e){ui.notifications.warn(e.message);return;}
 const {token,actions}=selected;
 const html=`<div class="mlb"><p>Токен: <strong>${escapeHTML(token.name)}</strong>. Выдели цели инструментом Target в Foundry. После этого нажми способность.</p>
 <label class="mlb-toggle"><input type="checkbox" id="mlb-auto-apply"/> Автоматически менять HP целей и накладывать состояния при провале спасброска</label>
 <p class="mlb-note">Без галочки модуль только бросает кости в чат. Особые способности боссов с перезарядкой 5–6 ведущий отслеживает вручную.</p>
 <div class="mlb-actions">${actions.map(a=>`<button type="button" data-action-key="${escapeHTML(a.key)}"><strong>${escapeHTML(a.name)}</strong><small>${a.mode==='attack'?`Атака +${a.bonus}`:`Спасбросок ${escapeHTML(a.save.toUpperCase())}, Сл ${a.dc}`} · ${escapeHTML(a.damage)} ${escapeHTML(a.damageType)}</small></button>`).join('')}</div></div>`;
 const dlg=new foundry.applications.api.DialogV2({window:{title:`Moonlighter — способности: ${token.name}`,resizable:true},content:html,buttons:[{action:'close',label:'Закрыть'}]});
 await dlg.render({force:true});
 for(const el of dlg.element.querySelectorAll('[data-action-key]'))el.addEventListener('click',async()=>{
   el.disabled=true;
   try{await performAction(el.dataset.actionKey,!!dlg.element.querySelector('#mlb-auto-apply')?.checked)}
   catch(e){console.error(e);ui.notifications.error(e.message)}finally{el.disabled=false;}
 });
}
Hooks.on('getSceneControlButtons',controls=>{
 if(!game.user?.isGM || !controls.tokens?.tools)return;
 const tools=controls.tokens.tools;
 tools['mlb-import']={name:'mlb-import',title:'Moonlighter Bestiary — импорт монстров',icon:'fa-solid fa-book-skull',order:Object.keys(tools).length,button:true,visible:true,onChange:()=>openCatalogue()};
 tools['mlb-actions']={name:'mlb-actions',title:'Moonlighter Bestiary — способности выбранного NPC',icon:'fa-solid fa-hat-wizard',order:Object.keys(tools).length,button:true,visible:true,onChange:()=>openActions()};
});
Hooks.once('ready',async()=>{
 if(game.system.id!=='dnd5e'){ui.notifications.warn('Moonlighter Bestiary работает с системой D&D 5e.');return;}
 try{await loadCatalogue();game.moonlighterBestiary={openCatalogue,openActions,importBiome,monsters:catalogue};
   console.info(`[${MODULE_ID}] Ready: ${catalogue.length} creatures`)}
 catch(e){console.error(`[${MODULE_ID}] Failed loading catalogue`,e);ui.notifications.error(e.message)}
});
