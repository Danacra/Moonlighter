/** Moonlighter Bestiary: original tabletop 5e adaptations, not official game stats. */
export const MODULE_ID = 'moonlighter-bestiary';
const round = n => Math.round(n);
const range = (n,lo,hi) => Math.max(lo,Math.min(hi,n));
export const slug = name => name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
const hashId = (seed) => {
  let h=2166136261;
  for (const char of seed) h=Math.imul(h ^ char.charCodeAt(0), 16777619) >>> 0;
  return Array.from({length:16}, (_,i)=>'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'[(h + 61*i + 17*i*i) % 62]).join('');
};
export const LABELS = {Golem:'Големы',Forest:'Лес',Desert:'Пустыня',Tech:'Технологии',Wanderer:'Странник',Universal:'Общие',Familiar:'Фамильяры'};
export const DAMAGE_RU = {bludgeoning:'дробящий',piercing:'колющий',slashing:'рубящий',force:'силовой',fire:'огонь',poison:'яд',lightning:'электричество',thunder:'гром'};
const oneDie = (cr, special=false) => cr < 1 ? 4 : cr < 3 ? 6 : cr < 6 ? 8 : cr < 11 ? 10 : 12;
const desc = text => `<p>${text.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')}</p>`;
function statScores(cr,role,arc) {
  const sturdy=['golem','machine','turret','serpent','mine','mimic'].includes(arc);
  const agile=['puppet','drone','specter','fungus','worm'].includes(arc);
  return {str:range(10+round(cr*0.8)+(sturdy?4:0),6,26),dex:range(11+round(cr*0.45)+(agile?3:0),7,22),
    con:range(10+round(cr*.75)+(sturdy?3:0),7,24),int:range(6+round(cr*.25)+(arc==='mage'?8:0),3,18),
    wis:range(9+round(cr*.35),6,18),cha:range(7+round(cr*.25)+(arc==='mage'?4:0),4,20)};
}
function buildPart(formula, type) {
  const m = String(formula).match(/^(\d+)d(\d+)(?:\+(\d+))?$/);
  if (!m) throw new Error(`Invalid damage formula: ${formula}`);
  return {number:Number(m[1]),denomination:Number(m[2]),bonus:m[3]||'',types:[type],custom:{enabled:false,formula:''},scaling:{mode:'',number:1,formula:''}};
}
function actionToItem(action, record) {
  const ident=hashId(record.id+action.key);
  const common={_id:ident,name:action.name,activation:{type:'action',value:1,condition:''},
    consumption:{targets:[],scaling:{allowed:false,max:''}},uses:{spent:0,recovery:[]},
    duration:{value:'',units:'inst'},range:{value:action.range||5,units:'ft'},target:{affects:{type:'creature',count:1},template:{type:'',size:''}}};
  const activity=action.mode==='attack' ? {
    ...common,type:'attack',attack:{ability:'',bonus:String(action.bonus),flat:true,type:{value:action.ranged?'ranged':'melee',classification:'weapon'}},
    damage:{includeBase:false,parts:[buildPart(action.damage,action.damageType)],critical:{bonus:''}}
  } : {
    ...common,type:'save',save:{ability:[action.save],dc:{calculation:'',formula:String(action.dc)}},
    damage:{onSave:'half',parts:[buildPart(action.damage,action.damageType)]}
  };
  return {
    name:action.name,type:'feat',img:action.icon||'icons/magic/symbols/rune-sigil-teal.webp',
    system:{type:{value:'monster'},description:{value:desc(action.description)},
      activation:{type:'action',cost:1,condition:''},uses:{spent:0,max:'',recovery:[]},
      activities:{[ident]:activity}},flags:{[MODULE_ID]:{abilityKey:action.key}}
  };
}
export function generateActions(record) {
  const cr=record.cr;const elite=record.role==='elite';const boss=record.role==='boss';
  const attacks=1+Math.floor(cr/5);const bonus=range(2+round(cr*.65),2,13);
  const die=oneDie(cr);
  const arc=record.archetype;
  const ranged=['turret','drone','machine','mage','electric'].includes(arc);
  const strikeName=arc==='slime'?'Слизистое касание':arc==='turret'?'Энергетический импульс':arc==='plant'?'Шиповидная лоза':arc==='specter'?'Эфирное касание':arc==='fungus'?'Споровой выброс':arc==='serpent'?'Укус':arc==='mage'?'Магический сгусток':arc==='drone'?'Искровой разряд':'Основная атака';
  const damage=`${attacks}d${die}+${Math.max(1,Math.floor(cr/2)+1)}`;
  const basic={key:'basic',mode:'attack',name:strikeName,bonus,damage,
    damageType:record.damage,ranged,range:ranged?60:5,
    description:`Атака существа. Бонус +${bonus} к попаданию; ${damage} (${DAMAGE_RU[record.damage]||record.damage}) урона.`};
  const saveDC=range(10+round(cr*.55)+(boss?1:0),10,19);
  const d2=oneDie(cr,true);
  const dice=boss?3:elite?2:1;
  const special={key:'special',mode:'save',name:record.special.name,save:record.special.save,dc:saveDC,
    damage:`${dice}d${d2}+${Math.max(1,round(cr*.38))}`,damageType:record.special.damage,
    condition:record.special.condition||'',ranged:true,range:30,
    description:`${record.special.text} Спасбросок ${record.special.save.toUpperCase()} Сл ${saveDC}. Урон при успехе уменьшается вдвое.${record.special.condition?' При провале накладывается состояние: '+record.special.condition+' на 1 раунд.':''}`};
  if (!boss) return [basic,special];
  const bossDistinct = {
    'the-golem-king':['Рокот каменного короля','str','thunder','prone'],
    'carnivorous-mutae':['Цветение ядовитого хищника','con','poison','poisoned'],
    'naja':['Песчаная буря Нажи','dex','fire','prone'],
    'energy-flux':['Перегрузка энергетического ядра','dex','lightning',''],
    'last-dimensional-pirate':['Вихрь пространственных разрывов','wis','force','frightened'],
    'enraged-wanderer':['Вопль междумирья','wis','psychic','frightened']
  }[record.id]||['Волна энергии','dex','force',''];
  const [name,save,dtype,condition]=bossDistinct;
  const mythic={key:'boss',mode:'save',name,save,dc:saveDC+1,damage:`4d${Math.min(12,die)}+${range(Math.round(cr),3,15)}`,
    damageType:dtype,condition,range:30,
    description:`Особая атака босса (перезарядка 5–6). Сл ${saveDC+1}; при успехе половина урона.${condition?' При провале: '+condition+' на 1 раунд.':''}`};
  return [basic,special,mythic];
}
export function makeActor(record) {
  const c=record.cr;const role=record.role;
  const crLabel=Number.isInteger(c)?String(c):({0.125:'1/8',0.25:'1/4',0.5:'1/2'}[c]||String(c));
  const hp=range(round(9+10*c+(role==='boss'?c*10:role==='elite'?c*4:0)),4,450);
  const ac=range(round(11+c*.55+(role==='boss'?2:0)),10,22);
  const ability=statScores(c,role,record.archetype);
  const actions=generateActions(record);
  const abilities=Object.fromEntries(Object.entries(ability).map(([k,value])=>[k,{value,proficient:k==='con'&&c>=4?1:0}]));
  const category=LABELS[record.biome]||record.biome;
  const size=role==='boss'?'huge':role==='familiar'?'tiny':['slime','drone','mine'].includes(record.archetype)?'sm':'med';
  return {
    name:record.name,type:'npc',img:`modules/${MODULE_ID}/art/portraits/${record.id}.webp`,
    prototypeToken:{name:record.name,displayName:20,actorLink:false,disposition:role==='familiar'?1:-1,
      width:role==='boss'?3:role==='elite'?2:1,height:role==='boss'?3:role==='elite'?2:1,
      texture:{src:`modules/${MODULE_ID}/art/tokens/${record.id}.webp`}},
    system:{abilities,traits:{size},attributes:{ac:{calc:'natural',flat:ac},hp:{value:hp,max:hp,formula:`${Math.max(1,Math.round(hp/7))}d8`},movement:{walk:role==='familiar'?40:30,units:'ft',hover:['specter','drone','electric'].includes(record.archetype)}},
      details:{cr:c,source:'Moonlighter (фанатская адаптация)',type:{value:record.archetype},biography:{value:`<h2>${record.name}</h2><p>Группа: ${category}. Роль: ${role}. Авторская адаптация для D&D 5e; неофициальные значения характеристик и способностей.</p>`}}},
    items:actions.map(a=>actionToItem(a,record)),
    flags:{[MODULE_ID]:{id:record.id,biome:record.biome,role:record.role,cr:record.cr,actions}}
  };
}
export function validateCatalogue(records){
 if(!Array.isArray(records)||records.length!==94)throw new Error('Expected 94 bestiary records');
 const ids=new Set();for(const r of records){if(ids.has(r.id))throw new Error('Duplicate '+r.id);ids.add(r.id);
 if(!r.name||!r.biome||!Number.isFinite(r.cr))throw new Error('Invalid record '+r.id);
 const a=makeActor(r);if(a.items.length<2||!a.img||!a.prototypeToken.texture.src)throw new Error('Incomplete actor '+r.id);
 }return true;
}
